# Fruits Recognition

This repository contains a project for **fruit recognition** using the Fruits-360 dataset. The project applies computer vision techniques, image segmentation, color histogram extraction, and machine learning classifiers to classify fruits into different categories.

---

## Features
 
- **Data Preprocessing**: Extracts color histograms from fruit images, segmenting fruits from the background using color thresholds and enhancing segmented images.
- **Segmentation**: Isolates fruits based on predefined color ranges using the HSV color space. A mask is applied to separate the fruit from the background.
- **Image Enhancement**: Improves segmented images via brightness/contrast adjustments, histogram equalization, denoising, and sharpening.
- **Feature Extraction**: Color histograms in the HSV color space represent the distribution of color components (Hue, Saturation, Value) for each image.
- **Machine Learning Models**: Includes SVM, KNN, and Random Forest classifiers for fruit recognition based on extracted features.
- **Model Evaluation**: Assesses models using accuracy, precision, recall, F1-score, and confusion matrices.

---

## Results

The **Random Forest** model outperformed SVM and KNN, achieving an accuracy of approximately **95%** on the test set.

---

## Flask Web Application

The trained machine learning model is deployed in a **Flask-based web application** for real-time fruit recognition. Users can upload fruit images and receive predictions instantly.

### Features of the Web Application:

- **Real-Time Prediction**: Upload an image, and the model predicts the fruit type in real time.
- **User-Friendly Interface**: Built with HTML, Bootstrap, and Tailwind CSS for a responsive and intuitive design.
- **Image Preview**: Displays an image preview after upload, prior to prediction.
- **Cross-Origin Requests (CORS)**: Secure communication between frontend and backend.
- **Error Handling**: Smooth user experience with error management for missing files or failed predictions.

### How It Works:

1. **Image Upload**: Users upload a fruit image via the form on the webpage.
2. **Image Preprocessing**: The uploaded image is resized and preprocessed to extract color histograms.
3. **Prediction**: The preprocessed image is passed to the **Random Forest** model to classify the fruit.
4. **Results Display**: The predicted fruit category is displayed to the user in real time.

---

## Technologies Used

- **Backend**: Flask for serving the machine learning model and managing HTTP requests.
- **Frontend**: HTML, Bootstrap, and Tailwind CSS for the user interface.
- **Machine Learning**: Random Forest model trained on color histogram features of fruit images.
- **Python**: Used for model development, image preprocessing, and backend functionality.
- **Google Colab**: For training and evaluating machine learning models in an experimental and optimized environment.

---

## Web Application Screenshots

![Screenshot 1](https://github.com/user-attachments/assets/f05cfd21-aa9d-4124-8fcf-d11cc14a2b17)  
![Screenshot 2](https://github.com/user-attachments/assets/3f303dab-6b6d-4816-9b1a-e4f602bae8fe)  
![Screenshot 3](https://github.com/user-attachments/assets/4dd5dd51-e6da-42ad-94b4-3f6acf94f0e0)  
![Screenshot 4](https://github.com/user-attachments/assets/b5bec280-102b-4ac9-b711-bec67a351d29)  

---

## Author

Developed by [@nouran246](https://github.com/nouran246) (Nouran Hassan).

---

## Contributions

Contributions are welcome! Feel free to open an issue or submit a pull request to improve the project.

---

## License

This project is licensed under the [MIT License](LICENSE).
